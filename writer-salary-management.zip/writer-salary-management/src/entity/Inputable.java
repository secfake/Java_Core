package entity;

public interface Inputable {

    void inputInfo();

}
